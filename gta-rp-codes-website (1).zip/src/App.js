import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

const HomePage = () => (
  <div className="p-4">
    <h1 className="text-2xl font-bold mb-4">Códigos Q e Códigos 0</h1>
    <h2 className="text-xl font-semibold">Códigos Q:</h2>
    <ul className="list-disc ml-5 mb-4">
      <li>QAP - Na escuta</li>
      <li>QRR - Urgência</li>
      <li>QRU - Não há alterações</li>
      <li>QTH - Localização</li>
    </ul>
    <h2 className="text-xl font-semibold">Códigos 0:</h2>
    <ul className="list-disc ml-5">
      <li>0 - Iniciando patrulhamento / Saindo de patrulhamento</li>
      <li>1 - Abordagem de rotina</li>
    </ul>
    <Link to="/modulacao" className="mt-4 inline-block text-blue-500">Ir para Modulação & GEO</Link>
  </div>
);

const ModulacaoPage = () => (
  <div className="p-4">
    <h1 className="text-2xl font-bold mb-4">Bases de Modulação e GEO</h1>
    <h2 className="text-xl font-semibold">Bases de Modulação:</h2>
    <ul className="list-disc ml-5 mb-4">
      <li>Base Alpha - Centro da cidade</li>
      <li>Base Bravo - Área industrial</li>
      <li>Base Charlie - Zona rural</li>
    </ul>
    <h2 className="text-xl font-semibold">Pontos no Mapa (GEO):</h2>
    <ul className="list-disc ml-5">
      <li>Delegacia Central</li>
      <li>Hospital Principal</li>
      <li>Praça do Centro</li>
    </ul>
    <Link to="/" className="mt-4 inline-block text-blue-500">Voltar para Códigos Q e 0</Link>
  </div>
);

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/modulacao" element={<ModulacaoPage />} />
    </Routes>
  </Router>
);

export default App;
